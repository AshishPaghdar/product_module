package com.liferay.karam.productdetails.web.constants;

//List of Actions for product details page.
public class ProductDetailsMVCCommandName {
	public static final String SHOW_INTEREST = "showInterest";
}
