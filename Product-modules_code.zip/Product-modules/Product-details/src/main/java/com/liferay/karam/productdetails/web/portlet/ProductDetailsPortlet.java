package com.liferay.karam.productdetails.web.portlet;

import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.productdetails.web.constants.ProductDetailsPortletKeys;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author root299
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Product Details",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ProductDetailsPortletKeys.PORTLET_NAME,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ProductDetailsPortlet extends MVCPortlet {
	private static final Log log = LogFactoryUtil.getLog(ProductDetailsPortlet.class.getName());
	
	@Reference
	ProductLocalService productLocalService;

	// Render for product details page.
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
				throws IOException, PortletException {
		long userId = 0;
		try {
			String goToPort="";
			HttpServletRequest httpServletRequest = PortalUtil.getHttpServletRequest(renderRequest);		
			HttpServletRequest originalhttpServletRequest  = PortalUtil.getOriginalServletRequest(httpServletRequest);
			HttpSession httpSession = originalhttpServletRequest.getSession();
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			userId = themeDisplay.getUserId();

			// Getting the productId and productImagespath from the product listing page(module)
			long productId = (Long) httpSession.getAttribute("productId");
			String productImagePath = (String) httpSession.getAttribute("productImagePath");
			
			// Getting the product by productId and set this product in the attribute. 
			if (productId != 0) {
				Product product =  productLocalService.getProduct(productId);
				product.setImagePath(productImagePath);
				goToPort = 	(String) httpSession.getAttribute("portletName")== null ?"":(String) httpSession.getAttribute("portletName");
				
				renderRequest.setAttribute("product", product);
				renderRequest.setAttribute("goToPort", goToPort);
			}else {
				log.info("Does not find out the productId by userId  :" + userId);
			}
			super.render(renderRequest, renderResponse);
		}catch (Exception e) {
			log.error("Error in Product Details Page :: by userId " + userId);
			e.printStackTrace();
		}
	}
}