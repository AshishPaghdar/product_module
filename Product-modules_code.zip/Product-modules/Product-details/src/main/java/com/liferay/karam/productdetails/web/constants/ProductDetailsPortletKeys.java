package com.liferay.karam.productdetails.web.constants;

/**
 * @author root299
 */
public class ProductDetailsPortletKeys {

	public static final String PORTLET_NAME =
		"com_liferay_karam_productdetails_web_portlet_ProductDetailsPortlet";
}