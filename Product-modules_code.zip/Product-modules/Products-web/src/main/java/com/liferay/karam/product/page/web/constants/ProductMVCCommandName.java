package com.liferay.karam.product.page.web.constants;

// List of Actions for product listing page.
public class ProductMVCCommandName {
	public static final String SHOW_INTEREST = "showInterest";
}
