package com.liferay.karam.product.page.web.action;


import com.liferay.karam.product.page.web.constants.ProductPagePortletKeys;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Layout;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
	immediate = true, 
	property = { 
		"javax.portlet.name=" + ProductPagePortletKeys.PORTLET_NAME,
		"mvc.command.name=" + com.liferay.karam.product.page.web.constants.ProductMVCCommandName.SHOW_INTEREST 
	}, 
	service = MVCActionCommand.class)

public class ShowInterestAction extends BaseMVCActionCommand{
	private static Logger log = LoggerFactory.getLogger(ShowInterestAction.class.getName());	


	// Show interest action from product Listing page for perticular product.
	// Redirect to product details page for the product.
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws IOException {
		ThemeDisplay td = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = td.getScopeGroupId();
		long userId = td.getUserId();
		HttpServletRequest httpServletRequest = PortalUtil
				.getOriginalServletRequest(PortalUtil.getHttpServletRequest(actionRequest));
		HttpSession httpSession = httpServletRequest.getSession();
	
		long productId = ParamUtil.getLong(actionRequest, "productId");
		String productImagePath = ParamUtil.getString(actionRequest, "productImagePath");
		log.info("***** Show Interest by userId : " + userId +  " For productId : " + productId);
		String URL = "";
		
		try {
			 Layout layout = LayoutLocalServiceUtil.getFriendlyURLLayout(groupId, true, "/product-details");
			 URL = PortalUtil.getLayoutFullURL(layout, td);
			 log.info("Product Details Page URL : " + URL);

			 actionResponse.sendRedirect(URL);
			 httpSession.setAttribute("productId", productId);
			 httpSession.setAttribute("productImagePath",productImagePath);
			
		} catch (PortalException e) {
			log.error("Error in Product Listing Page from Show Interest :: productId : " + productId + ", userId : " + userId);
			e.printStackTrace();
			actionResponse.setRenderParameter("jspPage", "/error.jsp");
		}
	}
}
