package com.liferay.karam.product.page.web.constants;

/**
 * @author root299
 */
public class ProductPagePortletKeys {

	public static final String PORTLET_NAME =
		"com_liferay_karam_product_page_web_portlet_ProductPagePortlet";
}