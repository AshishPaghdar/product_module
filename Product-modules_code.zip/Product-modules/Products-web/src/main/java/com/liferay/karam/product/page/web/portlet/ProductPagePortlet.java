package com.liferay.karam.product.page.web.portlet;

import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppService;
import com.liferay.document.library.kernel.service.DLFolderLocalServiceUtil;
import com.liferay.document.library.kernel.util.comparator.RepositoryModelTitleComparator;
import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.page.web.constants.ProductPagePortletKeys;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.product.service.ProductService;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.Repository;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.repository.RepositoryProvider;
import com.liferay.portal.kernel.repository.capabilities.BulkOperationCapability.Field.FolderId;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author root299
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Product Page",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ProductPagePortletKeys.PORTLET_NAME,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ProductPagePortlet extends MVCPortlet {
private static final Log log = LogFactoryUtil.getLog(ProductPagePortlet.class.getName());
	
	@Reference
	ProductLocalService productLocalService;
	
	@Reference
	private DLAppService _dlAppService;
	
	@Reference
	private RepositoryProvider repositoryProvider;
	
	@Reference
	private ProductService productService;
	
	// Render for product listing page.
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
				throws IOException, PortletException {
		  long userId=0;
		  
		try {
			String searchKeywords="";
			List<Product> poductList =new ArrayList<Product>();
			long pathFolderId = 0;
			String pathFileName, pathUuid, imagePath, noImagePath="";
			boolean imageStatus = false;
	
			HttpServletRequest httpServletRequest = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));
			HttpSession httpSession = httpServletRequest.getSession();
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			String portalURL = themeDisplay.getURLPortal();	
			long groupId = themeDisplay.getScopeGroupId();
			userId = themeDisplay.getUserId();
			
			log.info("***** Started the product listing page by userId :" + userId );
			//Search the products by keywords and order By Product.
			if(httpServletRequest.getParameter("searchKeywords")!=null && !httpServletRequest.getParameter("searchKeywords").equals(""))
			    searchKeywords = httpServletRequest.getParameter("searchKeywords");
			OrderByComparator<Product> comparator = OrderByComparatorFactoryUtil.create("Product", "productName", ("asc").equals("asc"));
			poductList = productService.getProductsByKeywords(groupId, searchKeywords, QueryUtil.ALL_POS, QueryUtil.ALL_POS, comparator);
			renderRequest.setAttribute("productList", poductList);
			renderRequest.setAttribute("searchKeywords", searchKeywords);
			
			
			/* Getting the product image name from the database and compare with DMS(liferay). 
			   Because we are getting the image path for show the product image on product listing page.  */
			Long parentFolderId = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
			long productImagesFolderId=0, repositoryId=0;
			List<FileEntry> fileEntries=null;
			
			// Getting the folderId of "PRODUCT_IMAGES" folder in DMS. This folder included all images of products.
			List<DLFolder> allFolders = DLFolderLocalServiceUtil.getFolders(groupId, parentFolderId);
			for (DLFolder folder : allFolders) {
				if(folder.getName().equals(PropsUtil.get("karam.product.images.foldername"))){
					productImagesFolderId = folder.getFolderId();
					Repository repository = repositoryProvider.getFolderRepository(productImagesFolderId);
					repositoryId = repository.getRepositoryId();
				}
			}
			
			// Getting the product images details in the "PRODUCT_IMAGES" folder.(you can change the folder name form DMS and properties file)
			if(repositoryId != 0 && productImagesFolderId != 0) {
				// Consider PNG and JPEG two types of images  
//				 fileEntries = 
//				        _dlAppService.getFileEntries(
//				        		repositoryId, 
//				        		productImagesFolderId,
//				                new String[] {ContentTypes.IMAGE_JPEG, ContentTypes.IMAGE_PNG}, 
//				                QueryUtil.ALL_POS, 
//				                QueryUtil.ALL_POS, 
//				                new RepositoryModelTitleComparator<>());
				
				// getting the all files from the productImagesFolderId.
				fileEntries = _dlAppService.getFileEntries(repositoryId, productImagesFolderId);
			}
			
			if(fileEntries!=null && poductList.size() != 0) {
				for (Product product : poductList) {
					
					int i=0;
					for (FileEntry fileEntry : fileEntries) {
						String imageName = fileEntry.getFileName();
						
						// If not matched the image name form DMS. while set the image "No image available" path from DMS.
						// This if loop ones time call for all products. Because we are getting the image path for "No image available".
						if(fileEntry.getFileName().equals(PropsUtil.get("karam.product.images.notAvailable")) && imageStatus==false) {
							pathFolderId = fileEntry.getFolderId();
							pathFileName = fileEntry.getFileName();
							pathUuid = fileEntry.getUuid();
							fileEntry.getGroupId();
							noImagePath = portalURL + "/documents/" + groupId + "/" + pathFolderId + "/" + pathFileName + "/" + pathUuid;
							imageStatus = true;
						}
						
						// If matched the image name entity(DMS) and product table then put the image path in the product.
						if(product.getImagePath().equals(imageName)) {
							pathFolderId = fileEntry.getFolderId();
							pathFileName = fileEntry.getFileName();
							pathUuid = fileEntry.getUuid();
							fileEntry.getGroupId();
							imagePath = portalURL + "/documents/" + groupId + "/" + pathFolderId + "/" + pathFileName + "/" + pathUuid;
							int index = poductList.indexOf(product);
							
							//Update fully path of product image and update the list.
							poductList.get(index).setImagePath(imagePath);
							i++;
							break;
						}else {  
							//If not fount the image in entity while finally put the image "No_Image_Available" path in the product list.(at last entity run)
							if(i++ == fileEntries.size() - 1 && noImagePath.length() > 0){ 
								int index = poductList.indexOf(product);
								poductList.get(index).setImagePath(noImagePath);
						    }
						}
					}
				}
	     	}else {
	     		log.info("Product List or Entity(DMS) Empty.... Please check images available in the folder(PRODUCT_IMAGES) and same the folder name declare in properties file.");
	     	}
			httpSession.setAttribute("portletName","/group/karam/products");
			super.render(renderRequest, renderResponse);		
		} catch (Exception e) {
			log.error("Error in Product Listing Page :: by userId " + userId);
			e.printStackTrace();
		}
	}	
}