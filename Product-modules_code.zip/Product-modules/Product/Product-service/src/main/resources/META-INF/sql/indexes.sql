create index IX_1BA1F9EE on Karam_Product (groupId, productId);
create index IX_67E0C64C on Karam_Product (productName[$COLUMN_LENGTH:75$]);
create index IX_6E383E77 on Karam_Product (productRefNo[$COLUMN_LENGTH:75$]);
create index IX_30EACAB2 on Karam_Product (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_ABAA55B4 on Karam_Product (uuid_[$COLUMN_LENGTH:75$], groupId);