/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.karam.product.service.impl;

import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.base.ProductLocalServiceBaseImpl;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.dao.orm.Disjunction;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Ashish Paghdar
 */
@Component(
	property = "model.class.name=com.liferay.karam.product.model.Product",
	service = AopService.class
)
public class ProductLocalServiceImpl extends ProductLocalServiceBaseImpl {
	public List<Product> getProductsByKeywords(long groupId, String keywords, int start, int end, OrderByComparator<Product> orderByComparator) {
		return productLocalService.dynamicQuery(getKeywordSearchDynamicQuery(groupId, keywords), start, end, orderByComparator);
	}
	
	private DynamicQuery getKeywordSearchDynamicQuery(long groupId, String keywords) {
		// Create A DynamicQuery For The Assiociated Group or Website
		DynamicQuery dynamicQuery = dynamicQuery().add(RestrictionsFactoryUtil.eq("groupId", groupId));
		
		if(Validator.isNotNull(keywords)) {
			// If Keywords Are Available For Search Operations. Create A Empty Disjunction Query Which Further Store Query Clauses
			Disjunction disjunctionQuery = RestrictionsFactoryUtil.disjunction();
			
			disjunctionQuery.add(RestrictionsFactoryUtil.like("productName", "%" + keywords + "%"));
			disjunctionQuery.add(RestrictionsFactoryUtil.like("productRefNo", "%" + keywords + "%"));
			
			// Update Disjunction Query To The Actual DynamicQuery
			dynamicQuery.add(disjunctionQuery);
		}
		
		return dynamicQuery;
	}
}