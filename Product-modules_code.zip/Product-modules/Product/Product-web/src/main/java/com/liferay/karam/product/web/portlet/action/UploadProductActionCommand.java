package com.liferay.karam.product.web.portlet.action;

import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.product.web.constants.ProductMVCCommandName;
import com.liferay.karam.product.web.constants.ProductWebPortletKeys;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + ProductWebPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + ProductMVCCommandName.ADD_PRODUCT }, service = MVCActionCommand.class)

public class UploadProductActionCommand extends BaseMVCActionCommand {
	private static final Log log = LogFactoryUtil.getLog(UploadProductActionCommand.class.getName());

	@Reference
	CounterLocalService counterLocalService;

	@Reference
	ProductLocalService productLocalService;

	@Reference
	UserLocalService userLocalService;

	// Upload products from xls/xlsx, csv file by admin.
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		long userId=0;
		try {
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Product.class.getName(), actionRequest);
			userId = serviceContext.getUserId();
			log.info("**** Started reading CSV file for Product by +" + userId + " User");
			UploadPortletRequest portletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
			File file = portletRequest.getFile("productDataFile", true);
			FileInputStream inputStream = new FileInputStream(file);

			//Make sure xls/xlsx file upload after 2007 + 
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheetAt(0);
			int lastRowOfSheet = firstSheet.getLastRowNum();
			int physicalNumberOfRows = firstSheet.getPhysicalNumberOfRows();
			
			Iterator<Row> rowIterator = firstSheet.iterator();

			// skip the header row
			rowIterator.next();
			
			boolean isValidFile;
			String invalidCellAddress = "";
			List<Product> productList = new ArrayList<Product>();
			
			// All row interation form xls/xlsx file. 
			while (rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();

				Product product = productLocalService
						.createProduct(counterLocalService.increment(UploadProductActionCommand.class.getName()));
				
				//Cell inteation for perticular product(Row)
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					CellAddress cellAddress  = nextCell.getAddress();
					int columnIndex = nextCell.getColumnIndex();

					//columnIndex indicated spreadsheet column index. 
					switch (columnIndex) {
					
					// For product name
					case 0:
						if (nextCell.getCellType() != CellType.NUMERIC) {
							String productName = nextCell.getStringCellValue();
							
							if(productName!=null && !productName.trim().equals("")) {
								product.setProductName(productName);
							}else {
								log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product name column by :" + userId + " User");
								invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
							}
						}else {
							log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product name column by :" + userId + " User");
							invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
						}
						break;

				    // For product description.
					case 1:
						if (nextCell.getCellType() == CellType.STRING) {
							String productDescription = nextCell.getStringCellValue();
							
							if(productDescription!=null && !productDescription.trim().equals("")) {
								product.setProductDescription(productDescription);
							}else {
								log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product description column by :" + userId + " User");
								invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
							}
						}else {
							log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product description column by :" + userId + " User");
							invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
						}
						break;

					// for product Ref. No.
					case 2:
						if (nextCell.getCellType() != CellType.NUMERIC) {
							String productRefNo = nextCell.getStringCellValue();

							if(productRefNo!=null && !productRefNo.equals("")) {
								product.setProductRefNo(productRefNo);
							}else {
								log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product Ref. No. column by :" + userId + " User");
								invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
							}
						}else {
							log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product Ref. No. column by :" + userId + " User");
							invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
						}
						break;
					
				    // For product Image name
					case 3:
						if (nextCell.getCellType() != CellType.NUMERIC) {
							String imapgePath = nextCell.getStringCellValue();

							if(imapgePath!=null && !imapgePath.equals("")) {
								product.setImagePath(imapgePath);
							}else {
								log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product Image Name column by :" + userId + " User");
								invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
							}
						}else {
							log.info(" :: Invalid Cell value " + cellAddress.toString() + " Address of Product Image Name column by :" + userId + " User");
							invalidCellAddress = invalidCellAddress + cellAddress.toString() + ", ";
						}
						break;

					}
				}
				
				// If all valid cell addresses in single recored(row/product) then put the product into the list. 
				if (invalidCellAddress.equals("")) {
					productList = addProductIntoList(actionRequest, actionResponse, product, productList);
				} 
			}
			
			// If all valid all row (all products) then add the all prodcuts in the database otherwise fatch the error.
			if (invalidCellAddress.equals("")) {
				addAllProduct(actionRequest, actionResponse, productList);
				SessionMessages.add(actionRequest, "successfully-uploded-product");	
			}else {
				log.info(" :: Failed Products Uploaded  by :" + userId + " User");
				actionRequest.setAttribute("invalidCellAddress", invalidCellAddress);
				SessionMessages.add(actionRequest, "invalid_cell_address");
			}
			workbook.close();
		} catch (Exception ex) {
			SessionErrors.add(actionRequest, "error");
			log.error("Error reading file by userId : " + userId + " :: Make sure xls/xlsx file supported 2007 +");
			ex.printStackTrace();
		}
	}

	// Add product into the list and returns the same product list.
	public List<Product> addProductIntoList(ActionRequest actionRequest, ActionResponse actionResponse, Product product, List<Product> productList)
			throws PortalException {
		Date createdDate = new Date();
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();

		// We Also Need Service Context For Our Add Operation
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Product.class.getName(), actionRequest);

		long userId = serviceContext.getUserId();
		User user = userLocalService.getUser(userId);
		String userName = user.getFullName();

		product.setGroupId(groupId);
		product.setCompanyId(companyId);
		product.setUserId(userId);
		product.setUserName(userName);
		product.setCreateDate(createdDate);
		product.setModifiedDate(createdDate);
		product.setIsActive(true);
		
		productList.add(product);
		return productList;
	}
	
	// Insert all products. It's all valid products.
	public void addAllProduct(ActionRequest actionRequest, ActionResponse actionResponse, List<Product> productList){
		for (Product product : productList) {
			productLocalService.addProduct(product);
		}
	}
	
}
