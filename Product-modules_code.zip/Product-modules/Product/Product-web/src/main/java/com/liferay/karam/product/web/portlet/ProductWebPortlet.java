package com.liferay.karam.product.web.portlet;

import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppService;
import com.liferay.document.library.kernel.service.DLFolderLocalServiceUtil;
import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.product.service.ProductService;
import com.liferay.karam.product.web.constants.ProductWebPortletKeys;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.repository.Repository;
import com.liferay.portal.kernel.repository.RepositoryProvider;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.util.PropsUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;


/**
 * @author root299
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Product",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ProductWebPortletKeys.PORTLET_NAME,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ProductWebPortlet extends MVCPortlet {
	
	private static final Log log = LogFactoryUtil.getLog(ProductWebPortlet.class.getName());
	
	@Reference
	ProductLocalService productLocalService;
	
	@Reference
	private RepositoryProvider repositoryProvider;
	
	@Reference
	private DLAppService _dlAppService;
	
	@Reference
	private ProductService productService;
	
	// Render for product module(Admin)
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
				throws IOException, PortletException {
		long userId=0;
		try {
			String goToPort="", searchKeywords="";
			
			HttpServletRequest httpServletRequest = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));
			HttpSession httpSession = httpServletRequest.getSession();
			goToPort = 	(String) httpSession.getAttribute("portletName")== null ?"":(String) httpSession.getAttribute("portletName");
			httpSession.setAttribute("portletName","/group/karam/product-listing");
			
			List<Product> poductList = new ArrayList<Product>();			
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			userId = themeDisplay.getUserId();
			long groupId = themeDisplay.getScopeGroupId();

			// Get the search keywords for product search.
		    if(httpServletRequest.getParameter("searchKeywords")!=null && !httpServletRequest.getParameter("searchKeywords").equals(""))
		    searchKeywords = httpServletRequest.getParameter("searchKeywords");
		    
		    // Order by productName with ASC order by default.
			OrderByComparator<Product> comparator = OrderByComparatorFactoryUtil.create("Product", "productName", ("asc").equals("asc"));
			
			// Getting the product list with keyword search and order by name.
			poductList = productService.getProductsByKeywords(groupId, searchKeywords, QueryUtil.ALL_POS, QueryUtil.ALL_POS, comparator);
			renderRequest.setAttribute("productList", poductList);
			renderRequest.setAttribute("searchKeywords", searchKeywords);
					
			/* Getting the xls file path form DMS for download the xls file(product)
			    */
			Long parentFolderId = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
			long productImagesFolderId=0, repositoryId=0;
			List<FileEntry> fileEntries=null;
			
			// Getting the folderId and repositoryId for xls file. This file included in the folder(PRODUCT_UPLOAD_SHEET) 
			List<DLFolder> allFolders = DLFolderLocalServiceUtil.getFolders(groupId, parentFolderId);
			if(allFolders.size()>0) {
				for (DLFolder folder : allFolders) {
					if(folder.getName().equals(PropsUtil.get("karam.product.xls.foldername"))){
						productImagesFolderId = folder.getFolderId();
						Repository repository = repositoryProvider.getFolderRepository(productImagesFolderId);
						repositoryId = repository.getRepositoryId();
					}
				}
			}else {
				log.info("***** Does not exist any folder for xls file(Upload_karam_product.xls). Please create the folder and put xls file for product in DMS and put the property karam.product.xls.foldername(PRODUCT_UPLOAD_SHEET) in portal-ext.properties file By UserId " + userId);
			}
			
			
			if(repositoryId != 0 && productImagesFolderId != 0) {
				fileEntries = 
				        _dlAppService.getFileEntries(repositoryId,productImagesFolderId);
			}else {
				log.info("***** Does not matched the folder name DMS and karam.product.xls.foldername(PRODUCT_UPLOAD_SHEET) in portal-ext.properties..... please varify By UserId " + userId);

			}
			long pathFolderId = 0;
			String pathFileName, pathUuid, xlsFilePath="";
			String portalURL = themeDisplay.getURLPortal();
			
			if(fileEntries!=null) {
					for (FileEntry fileEntry : fileEntries) {
						if(fileEntry.getFileName().equals(PropsUtil.get("karam.product.xls.filename"))){
							pathFolderId = fileEntry.getFolderId();
							pathFileName = fileEntry.getFileName();
							pathUuid = fileEntry.getUuid();
							fileEntry.getGroupId();
							xlsFilePath = portalURL + "/documents/" + groupId + "/" + pathFolderId + "/" + pathFileName + "/" + pathUuid;
							
							//set fully path of xls file of product upload.
							renderRequest.setAttribute("xlsFilePath", xlsFilePath);
						}
					}
	     	}else {
	     		log.info("***** Does not exist any file for download product xls file.  Please create xls file for product and put in the folder. Make sure same file name in DMS and karam.product.xls.filename(Upload_karam_product.xls) in portal-ext.properties file By UserId :" + userId);
	     	}
			
			if(xlsFilePath.equals("")) {
				log.info("***** Does not matched the file name DMS and karam.product.xls.filename(Upload_karam_product.xls)property in portal-ext.properties By UserId : " + userId);
			}
			super.render(renderRequest, renderResponse);		
		} catch (Exception e) {
			log.error("Error in Product module (Admin side) :: by userId " + userId);
		}
	}
}