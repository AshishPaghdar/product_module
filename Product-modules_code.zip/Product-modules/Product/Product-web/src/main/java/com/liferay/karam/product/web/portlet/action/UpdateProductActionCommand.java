package com.liferay.karam.product.web.portlet.action;

import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.product.web.constants.ProductMVCCommandName;
import com.liferay.karam.product.web.constants.ProductWebPortletKeys;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalService;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + ProductWebPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + ProductMVCCommandName.UPDATE_PRODUCT }, service = MVCActionCommand.class)

public class UpdateProductActionCommand extends BaseMVCActionCommand {
	private static final Log log = LogFactoryUtil.getLog(UpdateProductActionCommand.class.getName());

	@Reference
	ProductLocalService productLocalService;

	@Reference
	UserLocalService userLocalService;

	// update the product action from product module(Admin)
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, IOException{
	   long userId=0;
		try {
			
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Product.class.getName(), actionRequest);
			userId = serviceContext.getUserId();
			
			// Getting the all fields updated value from the product list.
			long productId = ParamUtil.getLong(actionRequest, "productId", GetterUtil.DEFAULT_LONG);
			String productName = ParamUtil.getString(actionRequest, "productName", GetterUtil.DEFAULT_STRING);
			String productDescription = ParamUtil.getString(actionRequest, "productDescription", GetterUtil.DEFAULT_STRING);
			String productRefNo = ParamUtil.getString(actionRequest, "productRefNo", GetterUtil.DEFAULT_STRING);
			String productImagePath = ParamUtil.getString(actionRequest, "imagePath", GetterUtil.DEFAULT_STRING);

			//sets all updated properties for the product.
			Product product = productLocalService.getProduct(productId);
			product.setProductId(productId);
			product.setProductName(productName);
			product.setProductDescription(productDescription);
			product.setProductRefNo(productRefNo);
			product.setImagePath(productImagePath);
			
			updateProduct(actionRequest, actionResponse, product);
			log.info("***** :: " + productName +  " Successfully Updated product by userId : " + userId);
			SessionMessages.add(actionRequest, "successfully-updated-product");
			actionResponse.setRenderParameter("jspPage", "/product/update-product.jsp");
			
		} catch (Exception ex) {
			SessionErrors.add(actionRequest, "error");
			log.error("Doesn't update the product by userId : " + userId);
			ex.printStackTrace();
		}
	}
	
	public void updateProduct(ActionRequest actionRequest, ActionResponse actionResponse, Product product)
			throws PortalException {

		Date createdDate = new Date();
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		long companyId = themeDisplay.getCompanyId();
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Product.class.getName(), actionRequest);

		long userId = serviceContext.getUserId();
		User user = userLocalService.getUser(userId);
		String userName = user.getFullName();

		product.setGroupId(groupId);
		product.setCompanyId(companyId);
		product.setUserId(userId);
		product.setUserName(userName);
		// set the current time in setModifiedDate() method and No need set the createdDate()
		product.setModifiedDate(createdDate);

		productLocalService.updateProduct(product);
	}
}
