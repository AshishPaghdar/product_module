package com.liferay.karam.product.web.constants;

// List of Action for product module(Administrator)
public class ProductMVCCommandName {
	public static final String ADD_PRODUCT = "/karam/product/add";
	public static final String UPDATE_PRODUCT = "/karam/product/update";
	public static final String DELETE_PRODUCT = "/karam/product/delete";
}
