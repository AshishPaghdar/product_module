package com.liferay.karam.product.web.portlet.action;

import com.liferay.karam.product.model.Product;
import com.liferay.karam.product.service.ProductLocalService;
import com.liferay.karam.product.web.constants.ProductMVCCommandName;
import com.liferay.karam.product.web.constants.ProductWebPortletKeys;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(immediate = true, property = { "javax.portlet.name=" + ProductWebPortletKeys.PORTLET_NAME,
		"mvc.command.name=" + ProductMVCCommandName.DELETE_PRODUCT }, service = MVCActionCommand.class)

public class DeleteProductActionCommand extends BaseMVCActionCommand {
	private static final Log log = LogFactoryUtil.getLog(DeleteProductActionCommand.class.getName());

	@Reference
	ProductLocalService productLocalService;

	// Delete the product from product list(Admin module)
	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, IOException{
	   long userId=0;
		try {
			
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Product.class.getName(), actionRequest);
			userId = serviceContext.getUserId();
			
			long productId = ParamUtil.getLong(actionRequest, "productId", GetterUtil.DEFAULT_LONG);
			String productName = ParamUtil.getString(actionRequest, "productName", GetterUtil.DEFAULT_STRING);
			productLocalService.deleteProduct(productId);
			
			log.info("**** :: " + productName +  " Successfully deleted product by userId :" + userId);
			SessionMessages.add(actionRequest, "successfully-deleted-product");
			
		} catch (Exception ex) {
			SessionErrors.add(actionRequest, "error");
			log.error("Doesn't product deleted by " + userId + " User Error :: " + ex);
		}
	}
}
