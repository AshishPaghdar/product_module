package com.liferay.karam.product.web.constants;

/**
 * @author root299
 */
public class ProductWebPortletKeys {

	public static final String PORTLET_NAME =
		"com_liferay_karam_product_web_portlet_ProductWebPortlet";

}